package ticket;

public class booking {

    String name;
    String email;
    int phone;
    int age;
    String pn;
    String tt;
    String noticket;

    public String getName() {
        return name;
    }
    public void setName(String name) {
        this.name = name;
    }
    public String getEmail() {
        return email;
    }
    public void setEmail(String email) {
        this.email = email;
    }
    public int getPhone() {
        return phone;
    }
    public void setPhone(int phone) {
        this.phone = phone;
    }
    public int getAge() {
        return age;
    }
    public void setAge(int age) {
        this.age = age;
    }
    public String getPn() {
        return pn;
    }
    public void setPn(String pn) {
        this.pn = pn;
    }
    public String getTt() {
        return tt;
    }
    public void setTt(String tt) {
        this.tt = tt;
    }
    public String getNoticket() {
        return noticket;
    }
    public void setNoticket(String noticket) {
        this.noticket = noticket;
    }

    


}

